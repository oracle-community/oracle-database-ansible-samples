startup upgrade;
alter pluggable database all open upgrade;
exit;
