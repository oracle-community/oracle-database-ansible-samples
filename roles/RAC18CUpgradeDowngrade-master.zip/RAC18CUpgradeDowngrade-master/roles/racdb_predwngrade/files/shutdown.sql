shutdown immediate;
exit;

