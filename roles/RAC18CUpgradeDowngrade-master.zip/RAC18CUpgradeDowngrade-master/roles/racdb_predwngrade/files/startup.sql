startup;
alter pluggable database all open;
exit;
