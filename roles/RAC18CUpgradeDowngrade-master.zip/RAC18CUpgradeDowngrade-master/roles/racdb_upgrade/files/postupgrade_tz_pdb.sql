alter session set container=${PDB_NAME}
@upg_tzv_apply.sql
