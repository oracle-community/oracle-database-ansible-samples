CONN / as sysdba
@countstatsTSTZ.sql
@upg_tzv_check.sql
